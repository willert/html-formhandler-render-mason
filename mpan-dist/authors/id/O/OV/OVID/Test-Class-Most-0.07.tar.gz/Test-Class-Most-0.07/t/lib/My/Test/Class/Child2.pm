package My::Test::Class::Child2;

# no need for any inheritance
sub child2 { 'from child2' }

1;
