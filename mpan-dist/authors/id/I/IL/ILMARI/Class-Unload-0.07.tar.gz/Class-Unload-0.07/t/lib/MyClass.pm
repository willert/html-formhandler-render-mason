package # Hide from the CPAN indexer
    MyClass;

our $VERSION = '0.01';

1;
