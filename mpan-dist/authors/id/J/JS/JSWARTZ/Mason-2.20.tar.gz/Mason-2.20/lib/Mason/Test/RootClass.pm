package Mason::Test::RootClass;
BEGIN {
  $Mason::Test::RootClass::VERSION = '2.20';
}
use strict;
use warnings;
use base qw(Mason);

1;
