package Mason::Test::Plugins::Notify;
BEGIN {
  $Mason::Test::Plugins::Notify::VERSION = '2.20';
}
use strict;
use warnings;
use base qw(Mason::Plugin);

1;
